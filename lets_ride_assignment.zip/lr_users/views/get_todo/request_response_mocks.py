


RESPONSE_200_JSON = """
{
    "description": "string",
    "is_completed": true,
    "remind_at": "string",
    "id": 1
}
"""

RESPONSE_401_JSON = """
{
    "response": "string",
    "http_status_code": 1,
    "res_status": "DUPLICATE_TO_IDS"
}
"""

RESPONSE_403_JSON = """
{
    "response": "string",
    "http_status_code": 1,
    "res_status": "DUPLICATE_TO_IDS"
}
"""

RESPONSE_404_JSON = """
{
    "response": "string",
    "http_status_code": 1,
    "res_status": "DUPLICATE_TO_IDS"
}
"""

