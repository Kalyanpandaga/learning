class ServiceAdapter:
    pass


def get_service_adapter():
    return ServiceAdapter()
