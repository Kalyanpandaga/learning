default_app_config = "lr_users.app.LrUsersAppConfig"  # pylint: disable=invalid-name

EXECUTE_API_TEST_CASE = True
__version__ = "0.0.1"
