# pylint: disable=wrong-import-position

APP_NAME = "lr_users"
OPERATION_NAME = "create_todo"
REQUEST_METHOD = "post"
URL_SUFFIX = "todos/"
