# pylint: disable=wrong-import-position

APP_NAME = "lr_users"
OPERATION_NAME = "get_todo"
REQUEST_METHOD = "get"
URL_SUFFIX = "todos/{id}/"
