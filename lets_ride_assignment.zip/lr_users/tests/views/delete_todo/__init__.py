# pylint: disable=wrong-import-position

APP_NAME = "lr_users"
OPERATION_NAME = "delete_todo"
REQUEST_METHOD = "delete"
URL_SUFFIX = "todos/{id}/"
