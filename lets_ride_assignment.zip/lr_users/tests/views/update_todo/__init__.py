# pylint: disable=wrong-import-position

APP_NAME = "lr_users"
OPERATION_NAME = "update_todo"
REQUEST_METHOD = "put"
URL_SUFFIX = "todos/{id}/"
