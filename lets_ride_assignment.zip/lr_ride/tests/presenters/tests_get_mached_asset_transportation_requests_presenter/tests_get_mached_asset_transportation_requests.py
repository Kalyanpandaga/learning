from lr_ride.presenters.\
    get_matched_asset_transportation_request_presenter_implementation import \
    GetMatchedAssetTransportationRequestPresenterImplementation
from lr_ride.tests.factories.interactor_dtos import \
    MatchedAssetTransportationRequestsWithUserDetailsDTOFactory


def tests_get_matched_asset_transportation_requests(snapshot):
    presenter = GetMatchedAssetTransportationRequestPresenterImplementation()
    matched_asset_transportation_requests_with_user_details = [
        MatchedAssetTransportationRequestsWithUserDetailsDTOFactory(),
        MatchedAssetTransportationRequestsWithUserDetailsDTOFactory()
    ]

    response = presenter.get_matched_asset_transportation_request_response(
        matched_asset_transportation_requests_with_user_details)

    import json

    content = response.content
    status_code = response.status_code

    snapshot.assert_match(json.loads(content), 'content')
    snapshot.assert_match(status_code, 'status_code')
