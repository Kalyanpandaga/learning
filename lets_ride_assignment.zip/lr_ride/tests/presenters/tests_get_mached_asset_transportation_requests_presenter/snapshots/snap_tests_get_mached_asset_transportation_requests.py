# -*- coding: utf-8 -*-
# snapshottest: v1 - https://goo.gl/zC4yUc
from __future__ import unicode_literals

from snapshottest import Snapshot


snapshots = Snapshot()

snapshots['tests_get_matched_asset_transportation_requests content'] = [
    {
        'Requester_details': {
            'user_id': 'user0',
            'user_name': 'user_name0'
        },
        'applied_status': [
            'APPLIED'
        ],
        'asset_sensitivity': 'HIGHLY_SENSITIVE',
        'asset_type': 'LAPTOP',
        'assets_quantity': 0,
        'end_datetime': '2022-11-23 18:19',
        'from_location': 'from_location0',
        'start_datetime': '2022-11-23 18:19',
        'to_location': 'to_location0',
        'whom_to_deliver': 'whom_to_delever0'
    },
    {
        'Requester_details': {
            'user_id': 'user1',
            'user_name': 'user_name1'
        },
        'applied_status': 'NOT_APPLIED',
        'asset_sensitivity': 'SENSITIVE',
        'asset_type': 'TRAVEL_BAG',
        'assets_quantity': 1,
        'end_datetime': '2022-11-23 18:19',
        'from_location': 'from_location1',
        'start_datetime': '2022-11-23 18:19',
        'to_location': 'to_location1',
        'whom_to_deliver': 'whom_to_delever1'
    }
]

snapshots['tests_get_matched_asset_transportation_requests status_code'] = 200
