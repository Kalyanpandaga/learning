from datetime import datetime

import pytest

from lr_ride.constants.enum import AppliedStatusEnum, OrderEnum
from lr_ride.storages.asset_transportation_request_storage_implementation import \
    AssetTransportationRequestStorageImplementation
from lr_ride.tests.factories.interactor_dtos import \
    MatchedRequestsRequiredDetailsDTOFactory, FilterByDTOFactory
from lr_ride.tests.factories.models import AssetTransportationRequestFactory
from lr_ride.tests.factories.storage_dtos import \
    MatchedAssetTransportationRequestsDetailsDTOFactory


@pytest.mark.django_db
class TestCreateAssetTransportationRequests:
    @pytest.fixture
    def matched_asset_transportation_request_data(self):
        user_ids = ['user1', 'user2']
        request_object1 = \
            AssetTransportationRequestFactory(
                user_id=user_ids[0],
                from_location='khammam',
                to_location='hyderabad',
                start_datetime=datetime(2022, 10, 11, 7, 12),
                end_datetime=datetime(2022, 10, 11, 9, 12),
                applied_status=AppliedStatusEnum.not_applied.value
            )

        request_object2 = \
            AssetTransportationRequestFactory(
                user_id=user_ids[0],
                from_location='warangal',
                to_location='hyderabad',
                start_datetime=datetime(2022, 10, 11, 7, 12),
                end_datetime=datetime(2022, 10, 11, 9, 12)
            )

        request_object3 = \
            AssetTransportationRequestFactory(
                user_id=user_ids[0],
                from_location='khammam',
                to_location='hyderabad',
                start_datetime=datetime(2022, 10, 11, 8, 12),
                applied_status=AppliedStatusEnum.not_applied.value,
                end_datetime=None,
            )

        request_object4 = \
            AssetTransportationRequestFactory(
                user_id=user_ids[0],
                from_location='khammam',
                to_location='hyderabad',
                start_datetime=datetime(2022, 10, 11, 7, 50),
                end_datetime=None,
            )

        request_object5 = \
            AssetTransportationRequestFactory(
                user_id=user_ids[0],
                from_location='khammam',
                to_location='hyderabad',
                start_datetime=datetime(2022, 10, 11, 12, 12),
                end_datetime=datetime(2022, 10, 11, 11, 12)
            )

        request_object6 = \
            AssetTransportationRequestFactory(
                user_id=user_ids[0],
                from_location='khammam',
                to_location='hyderabad',
                start_datetime=datetime(2022, 10, 11, 7, 12),
                end_datetime=datetime(2022, 10, 11, 9, 12),
                applied_status=AppliedStatusEnum.applied.value
            )
        request_object7 = \
            AssetTransportationRequestFactory(
                user_id=user_ids[1],
                from_location='khammam',
                to_location='hyderabad',
                start_datetime=datetime(2022, 10, 11, 7, 12),
                end_datetime=datetime(2022, 10, 11, 9, 12)
            )

        matched_requests_required_details = \
            MatchedRequestsRequiredDetailsDTOFactory(
                user_id=user_ids[0],
                sort_by=OrderEnum.desc.value,
                filter=None,
                from_location='khammam',
                to_location='hyderabad',
                datetime=datetime(2022, 10, 11, 8, 12),
                limit=10,
                offset=0
            )

        matched_asset_transportation_requests_details = [
            MatchedAssetTransportationRequestsDetailsDTOFactory(
                user_id=request_object6.user_id,
                from_location=request_object6.from_location,
                to_location=request_object6.to_location,
                start_datetime=request_object6.start_datetime,
                end_datetime=request_object6.end_datetime,
                assets_quantity=request_object6.assets_quantity,
                asset_type=request_object6.asset_type,
                asset_sensitivity=request_object6.asset_sensitivity,
                whom_to_deliver=request_object6.whom_to_deliver,
                applied_status=request_object6.applied_status
            ),
            MatchedAssetTransportationRequestsDetailsDTOFactory(
                user_id=request_object3.user_id,
                from_location=request_object3.from_location,
                to_location=request_object3.to_location,
                start_datetime=request_object3.start_datetime,
                end_datetime=request_object3.end_datetime,
                assets_quantity=request_object3.assets_quantity,
                asset_type=request_object3.asset_type,
                asset_sensitivity=request_object3.asset_sensitivity,
                whom_to_deliver=request_object3.whom_to_deliver,
                applied_status=request_object3.applied_status
            ),
            MatchedAssetTransportationRequestsDetailsDTOFactory(
                user_id=request_object1.user_id,
                from_location=request_object1.from_location,
                to_location=request_object1.to_location,
                start_datetime=request_object1.start_datetime,
                end_datetime=request_object1.end_datetime,
                assets_quantity=request_object1.assets_quantity,
                asset_type=request_object1.asset_type,
                asset_sensitivity=request_object1.asset_sensitivity,
                whom_to_deliver=request_object1.whom_to_deliver,
                applied_status=request_object1.applied_status
            )
        ]

        return matched_requests_required_details, \
               matched_asset_transportation_requests_details

    def test_when_filter_none_and_order_desc(
            self, matched_asset_transportation_request_data):
        # arrange
        matched_requests_required_details, \
        expected_matched_asset_transportation_requests_details = \
            matched_asset_transportation_request_data

        storage = AssetTransportationRequestStorageImplementation()

        # act
        actual_matched_asset_transportation_requests_details = \
            storage.get_matched_asset_transportation_requests(
                matched_requests_required_details)

        assert actual_matched_asset_transportation_requests_details == \
               expected_matched_asset_transportation_requests_details

    def test_when_filter_on_applied(
            self, matched_asset_transportation_request_data):
        # arrange
        matched_requests_required_details, \
        expected_matched_asset_transportation_requests_details = \
            matched_asset_transportation_request_data

        filter_by = FilterByDTOFactory(
            applied_status=AppliedStatusEnum.applied.value)

        matched_requests_required_details.filter = filter_by

        expected_matched_asset_transportation_requests_details = \
            expected_matched_asset_transportation_requests_details[0:1]

        storage = AssetTransportationRequestStorageImplementation()

        # act
        actual_matched_asset_transportation_requests_details = \
            storage.get_matched_asset_transportation_requests(
                matched_requests_required_details)

        print(actual_matched_asset_transportation_requests_details)
        print(expected_matched_asset_transportation_requests_details)

        assert actual_matched_asset_transportation_requests_details == \
               expected_matched_asset_transportation_requests_details

    def test_when_filter_on_not_applied_and_order_asc(
            self, matched_asset_transportation_request_data):
        # arrange
        matched_requests_required_details, \
        expected_matched_asset_transportation_requests_details = \
            matched_asset_transportation_request_data

        filter_by = FilterByDTOFactory(
            applied_status=AppliedStatusEnum.not_applied.value)

        matched_requests_required_details.filter = filter_by
        matched_requests_required_details.sort_by = OrderEnum.asc.value

        expected_matched_asset_transportation_requests_details = \
            expected_matched_asset_transportation_requests_details[1:][::-1]

        storage = AssetTransportationRequestStorageImplementation()

        # act
        actual_matched_asset_transportation_requests_details = \
            storage.get_matched_asset_transportation_requests(
                matched_requests_required_details)

        assert actual_matched_asset_transportation_requests_details == \
               expected_matched_asset_transportation_requests_details

    def test_when_filter_and_offset_values_are_given(
            self, matched_asset_transportation_request_data):
        # arrange
        matched_requests_required_details, \
            expected_matched_asset_transportation_requests_details = \
            matched_asset_transportation_request_data

        limit = 2
        offset = 1
        matched_requests_required_details.limit = 2
        matched_requests_required_details.offset = 1
        expected_matched_asset_transportation_requests_details = \
            expected_matched_asset_transportation_requests_details[
                offset: limit + offset]

        storage = AssetTransportationRequestStorageImplementation()

        # act
        actual_matched_asset_transportation_requests_details = \
            storage.get_matched_asset_transportation_requests(
                matched_requests_required_details)

        assert actual_matched_asset_transportation_requests_details == \
               expected_matched_asset_transportation_requests_details
