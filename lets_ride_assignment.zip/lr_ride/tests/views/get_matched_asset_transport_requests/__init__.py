# pylint: disable=wrong-import-position

APP_NAME = "lr_ride"
OPERATION_NAME = "get_matched_asset_transport_requests"
REQUEST_METHOD = "post"
URL_SUFFIX = "user/matched_requests/v1/"
