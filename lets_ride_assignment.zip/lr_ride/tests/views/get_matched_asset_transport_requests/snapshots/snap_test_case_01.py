# -*- coding: utf-8 -*-
# snapshottest: v1 - https://goo.gl/zC4yUc
from __future__ import unicode_literals

from snapshottest import Snapshot


snapshots = Snapshot()

snapshots['TestCase01GetMatchedAssetTransportRequestsAPITestCase.test_case status_code'] = '200'

snapshots['TestCase01GetMatchedAssetTransportRequestsAPITestCase.test_case body'] = [
    {
        'Requester_details': {
            'user_id': '227f4323-d191-471c-81f9-2da1b4f675fe',
            'user_name': 'user_name0'
        },
        'applied_status': 'NOT_APPLIED',
        'asset_sensitivity': 'HIGHLY_SENSITIVE',
        'asset_type': 'LAPTOP',
        'assets_quantity': 0,
        'end_datetime': '2022-10-11 09:12',
        'from_location': 'khammam',
        'start_datetime': '2022-10-11 07:12',
        'to_location': 'hyderabad',
        'whom_to_deliver': 'whom_to_delever0'
    },
    {
        'Requester_details': {
            'user_id': '227f4323-d191-471c-81f9-2da1b4f675fe',
            'user_name': 'user_name0'
        },
        'applied_status': 'NOT_APPLIED',
        'asset_sensitivity': 'NORMAL',
        'asset_type': 'PACKAGE',
        'assets_quantity': 2,
        'end_datetime': None,
        'from_location': 'khammam',
        'start_datetime': '2022-10-11 08:12',
        'to_location': 'hyderabad',
        'whom_to_deliver': 'whom_to_delever2'
    }
]
