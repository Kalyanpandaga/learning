# pylint: disable=wrong-import-position

APP_NAME = "lr_ride"
OPERATION_NAME = "create_asset_transport_request"
REQUEST_METHOD = "post"
URL_SUFFIX = "user/asset_transporataion/request/v1/"
