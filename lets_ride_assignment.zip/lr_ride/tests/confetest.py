import pytest

from lr_ride.tests.factories.adapter_dtos import UserDetailsDTOFactory
from lr_ride.tests.factories.interactor_dtos import \
    MatchedAssetTransportationRequestsWithUserDetailsDTOFactory


@pytest.fixture(autouse=True)
def reset_interactor_factories_sequences():
    MatchedAssetTransportationRequestsWithUserDetailsDTOFactory.reset_sequence()
    MatchedAssetTransportationRequestsWithUserDetailsDTOFactory.asset_type.reset()
    MatchedAssetTransportationRequestsWithUserDetailsDTOFactory.\
        asset_sensitivity.reset()
    MatchedAssetTransportationRequestsWithUserDetailsDTOFactory.\
        applied_status.reset()
    UserDetailsDTOFactory.reset_sequence()
