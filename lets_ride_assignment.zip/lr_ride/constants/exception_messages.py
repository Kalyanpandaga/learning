INVALID_ASSET_TYPE = 'Invalid asset type {}'
INVALID_ASSET_SENSITIVITY = 'Invalid asset sensitivity {}'
INVALID_APPLIED_STATUS = 'Invalid applied status {}'
INVALID_TRAVEL_MEDIUM = 'Invalid travel medium {}'
