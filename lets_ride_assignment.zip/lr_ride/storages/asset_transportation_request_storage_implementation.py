from typing import List

from lr_ride.constants.enum import OrderEnum
from lr_ride.interactors.interactor_dtos import \
    AssetTransportationRequestDetailsDTO, MatchedRequestsRequiredDetailsDTO
from lr_ride.interactors.storage_interfaces. \
    asset_transportation_request_storage_interface import \
    AssetTransportationRequestStorageInterface
from lr_ride.interactors.storage_interfaces.dtos import \
    MatchedAssetTransportationRequestsDetailsDTO
from lr_ride.models.asset_transportation_request import \
    AssetTransportationRequest
from django.db.models import Q


class AssetTransportationRequestStorageImplementation(
        AssetTransportationRequestStorageInterface):
    def create_asset_transportation_request(
            self,
            asset_transportation_request_details: AssetTransportationRequestDetailsDTO):
        AssetTransportationRequest.objects.create(
            user_id=asset_transportation_request_details.user_id,
            from_location=asset_transportation_request_details.from_location,
            to_location=asset_transportation_request_details.to_location,
            start_datetime=asset_transportation_request_details.start_datetime,
            end_datetime=asset_transportation_request_details.end_datetime,
            assets_quantity=asset_transportation_request_details.assets_quantity,
            asset_type=asset_transportation_request_details.asset_type,
            asset_sensitivity=asset_transportation_request_details.asset_sensitivity,
            whom_to_deliver=asset_transportation_request_details.whom_to_deliver,
        )

    def get_matched_asset_transportation_requests(
            self, matched_requests_required_details: MatchedRequestsRequiredDetailsDTO) \
            -> List[MatchedAssetTransportationRequestsDetailsDTO]:
        request_user_id = matched_requests_required_details.user_id
        sort_by = matched_requests_required_details.sort_by
        filter_by_dto = matched_requests_required_details.filter
        from_location = matched_requests_required_details.from_location
        to_location = matched_requests_required_details.to_location
        datetime = matched_requests_required_details.datetime
        limit = matched_requests_required_details.limit
        offset = matched_requests_required_details.offset

        user_asset_transportation_requests = \
            AssetTransportationRequest.objects.filter(
                user_id=request_user_id,
                from_location=from_location,
                to_location=to_location
            )

        if filter_by_dto is not None:
            applied_status = filter_by_dto.applied_status
            user_asset_transportation_requests = \
                user_asset_transportation_requests.filter(
                    applied_status=applied_status)

        user_asset_transportation_requests = \
            user_asset_transportation_requests.filter(
                Q(end_datetime__isnull=True, start_datetime=datetime) |
                Q(end_datetime__isnull=False, start_datetime__lte=datetime,
                  end_datetime__gte=datetime)
            )

        if sort_by == OrderEnum.asc.value:
            user_asset_transportation_requests = \
                user_asset_transportation_requests.order_by(
                    'creation_datetime')[offset:offset+limit]
        else:
            user_asset_transportation_requests = \
                user_asset_transportation_requests.order_by(
                    '-creation_datetime')[offset:offset+limit]

        matched_asset_transportation_requests_details = []
        for asset_transportation_request in user_asset_transportation_requests:
            matched_asset_transportation_requests_details.append(
                MatchedAssetTransportationRequestsDetailsDTO(
                    user_id=asset_transportation_request.user_id,
                    from_location=asset_transportation_request.from_location,
                    to_location=asset_transportation_request.to_location,
                    start_datetime=asset_transportation_request.start_datetime,
                    end_datetime=asset_transportation_request.end_datetime,
                    assets_quantity=asset_transportation_request.assets_quantity,
                    asset_type=asset_transportation_request.asset_type,
                    asset_sensitivity=asset_transportation_request.asset_sensitivity,
                    whom_to_deliver=asset_transportation_request.whom_to_deliver,
                    applied_status=asset_transportation_request.applied_status
                )
            )

        return matched_asset_transportation_requests_details





