

REQUEST_BODY_JSON = """
{
    "from_location": "string",
    "to_location": "string",
    "start_datetime": "string",
    "end_datetime": "string",
    "assets_quantity": 1,
    "asset_type": "LAPTOP",
    "asset_sensitivity": "HIGHLY_SENSITIVE",
    "whom_to_deliver": "string"
}
"""


