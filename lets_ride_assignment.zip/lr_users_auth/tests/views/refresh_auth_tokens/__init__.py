# pylint: disable=wrong-import-position

APP_NAME = "lr_users_auth"
OPERATION_NAME = "refresh_auth_tokens"
REQUEST_METHOD = "post"
URL_SUFFIX = "refresh_auth_tokens/v1/"
