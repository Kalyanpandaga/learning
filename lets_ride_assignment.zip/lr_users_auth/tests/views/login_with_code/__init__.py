# pylint: disable=wrong-import-position

APP_NAME = "lr_users_auth"
OPERATION_NAME = "login_with_code"
REQUEST_METHOD = "post"
URL_SUFFIX = "login/v1/"
