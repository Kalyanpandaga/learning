# pylint: disable=wrong-import-position

APP_NAME = "lr_users_auth"
OPERATION_NAME = "get_user_profile"
REQUEST_METHOD = "get"
URL_SUFFIX = "user/profile/v1/"
