# pylint: disable=wrong-import-position

APP_NAME = "lr_users_auth"
OPERATION_NAME = "logout_in_all_devices"
REQUEST_METHOD = "post"
URL_SUFFIX = "logout_in_all_devices/v1/"
