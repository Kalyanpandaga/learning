default_app_config = "lr_users_auth.app.LrUsersAuthAppConfig" # pylint:disable=invalid-name

EXECUTE_API_TEST_CASE = True
__version__ = '0.0.1'
