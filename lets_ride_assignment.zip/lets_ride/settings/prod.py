from lets_ride.settings.base_server import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False
